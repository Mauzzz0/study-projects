package com.bsbo0419.Semak;

import com.bsbo0419.Semak.task1.tmp1;
import com.bsbo0419.Semak.task2.tmp2;
import com.bsbo0419.Semak.task3.tmp3;
import com.bsbo0419.Semak.task4.tmp4;

public class Main {

    public static void main(String[] args) {
        tmp4 _tmp = new tmp4();
        //_tmp._main();


        _tmp.cats.remove(_tmp.returnCat());
        _tmp.show();
    }
}
