package com.bsbo0419.Semak.task1;

public class tmp1 {
    public static class Feline{

    }
    public static class Cat extends Feline{

    }
    public static class FatCat extends Feline{

    }
    public static class SkinnyCat extends Feline{

    }
    public void _main(){
        Feline tmp0 = new Feline();
        Cat tmp1 = new Cat();
        System.out.println(tmp0);
        System.out.println(tmp1);
    }
}
